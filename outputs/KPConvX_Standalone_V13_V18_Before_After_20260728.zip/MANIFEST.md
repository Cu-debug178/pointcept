# KPConvX Standalone V13/V18 前后对照包

生成日期：2026-07-28

## 基准来源

- 官方仓库：`https://github.com/apple/ml-kpconvx`
- 官方 commit：`54e644a9f3bddd4c344a58193897a44582b0fea4`
- `before/Standalone/`：上述 commit 的原始 `Standalone` 完整源码快照。
- `after/Standalone/`：当前项目内的 Standalone 完整源码快照。
- `after/project_tests/`：本项目针对 V13/V18 图逻辑的单元测试。
- `after/research_reviews/`：GPT-5.6 Pro 原始评审与实际落地记录。
- `UPSTREAM_LICENSE`：Apple 上游仓库根目录中的许可证原文。

缓存文件 `__pycache__/*.pyc` 不属于源码，已从两个快照排除。

## 直接修改的官方文件

- `KPConvX/experiments/S3DIS/train_S3DIS.py`

该文件增加 V13/V18 配置、参数解析和显式模型选择。两个开关默认均为关闭，因此默认仍实例化官方 `KPNeXt`。

## 本次新增文件

- `KPConvX/utils/da_radius.py`
- `KPConvX/models/KPNextV13.py`
- `train_S3DIS_v13.sh`
- `train_S3DIS_v13_conservative.sh`
- `V13_STANDALONE.md`
- `KPConvX/utils/dual_support.py`
- `KPConvX/models/KPNextV18.py`
- `KPConvX/experiments/S3DIS/audit_S3DIS_v18.py`
- `train_S3DIS_v18_diagnostic.sh`
- `train_S3DIS_v18_formal.sh`
- `audit_S3DIS_v18.sh`
- `V18_DUAL_SUPPORT.md`
- `SOURCE.md`
- `LICENSE`：随第三方源码副本补充的上游许可证，不属于算法改动。

## 如何比较

直接递归比较 `before/Standalone/` 与 `after/Standalone/`。重点先检查唯一被修改的官方入口文件，再审查上述新增文件。

## 证据边界

已证实：纯图逻辑测试通过、Python 语法编译通过、构造 smoke 通过，ring 分支满足无 ring 时零增量及 `gamma=0` 恒等。

尚未证实：真实 S3DIS CUDA 前向、峰值显存、吞吐、最终 mIoU、边界类别收益和多 seed 稳定性。本包中的实现不能被表述为已经提升精度。
