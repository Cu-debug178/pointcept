# 文件清单

- `UPSTREAM_LICENSE`：Apple 上游仓库根目录许可证原文。

## 评审依据

- `evidence/GPT-5.6Pro_V13到V18双支持改造评审原文_20260728.md`
- `evidence/GPT-5.6Pro_V18改造落地记录_20260728.md`
- `evidence/V13_STANDALONE.md`
- `evidence/V18_DUAL_SUPPORT.md`
- `evidence/SOURCE.md`

## 核心代码

- `source/external/ml-kpconvx-standalone/KPConvX/utils/da_radius.py`
- `source/external/ml-kpconvx-standalone/KPConvX/utils/dual_support.py`
- `source/external/ml-kpconvx-standalone/KPConvX/models/KPNextV13.py`
- `source/external/ml-kpconvx-standalone/KPConvX/models/KPNextV18.py`
- `source/external/ml-kpconvx-standalone/KPConvX/experiments/S3DIS/train_S3DIS.py`
- `source/external/ml-kpconvx-standalone/KPConvX/experiments/S3DIS/audit_S3DIS_v18.py`

## 启动脚本

- `source/external/ml-kpconvx-standalone/train_S3DIS_v13.sh`
- `source/external/ml-kpconvx-standalone/train_S3DIS_v13_conservative.sh`
- `source/external/ml-kpconvx-standalone/train_S3DIS_v18_diagnostic.sh`
- `source/external/ml-kpconvx-standalone/train_S3DIS_v18_formal.sh`
- `source/external/ml-kpconvx-standalone/audit_S3DIS_v18.sh`

## 测试

- `tests/test_standalone_v13_da_radius.py`
- `tests/test_standalone_v18_dual_support.py`
