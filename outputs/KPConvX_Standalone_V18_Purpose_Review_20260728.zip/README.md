# KPConvX Standalone V18 改动目的审查包

## 审查目标

本包用于检查 V18 双支持机制是否正确实现，以及该机制是否值得进入真实 S3DIS 强诊断实验。它不提供“已经提升精度”的证据。

## 需要解决的问题

V13 只改变自适应半径和核点几何，但原始邻接图受固定最近 `H` 邻居约束。在很多查询点已经拥有足够近邻时，扩大半径可能不会增加任何邻居，导致机制在图层面基本不发生变化。因此，“参数范围偏保守”不是唯一解释；固定 `H` 造成的邻接图不变是更优先需要验证的结构问题。

## V18 核心假设

1. 官方最近 `H` 邻居保留为 identity path，确保基线语义可辨识。
2. 单独构建更大的候选图，ring 只读取 `H` 之后且满足 `r_base < d <= r_adaptive` 的新增邻居。
3. ring 残差使用固定 `gamma=0.25` 做强机制诊断；若连强诊断都无法形成足够图变化，则不应直接投入正式多 seed 训练。
4. kernel points 和 influence sigma 同步乘逐点 scale，避免扩大邻域后仍用未缩放核几何解释远邻居。
5. 密度变量使用 `mean KNN distance / stage grid size`，降低不同 stage 尺度不可比的问题。

## 强诊断配置

Standalone 使用一基 stage 编号。stage 3/4 对应评审中的零基 stage 2/3。

| 配置 | Stage 3 | Stage 4 |
| --- | ---: | ---: |
| Base H | 20 | 20 |
| Candidate K | 40 | 48 |
| Ring 上限 | 8 | 12 |
| Scale 范围 | 0.75-1.45 | 0.70-1.55 |
| Gamma | 0.25 fixed | 0.25 fixed |

## 必查实现不变量

- 默认配置仍走官方 `KPNeXt`。
- V13 与 V18 开关互斥。
- identity path 的邻居索引和基线最近 `H` 邻居完全一致。
- ring 与 identity 不重复使用相同候选槽位。
- 不满足半径条件或 padding 的 ring 项必须被 mask。
- 无 ring 时残差严格为零；`gamma=0` 时输出严格等于 identity path。
- `EasyDict` 的 stage 映射使用字符串键，模型内部再转整数。
- `v18_formal` 在缺少训练集固定 spacing q10/q90 时必须拒绝启动。

## 训练前审计指标

- base/adaptive radius 内平均点数；
- base radius 内达到 `H` 个候选的比例；
- 每点新增 ring 邻居均值；
- 邻接图 change rate；
- `d_H / base_radius`；
- scale 与无量纲 spacing 分位数。

当新增邻居均值小于 1 或 graph change 小于 10% 时，应停止继续调 scale，先检查候选图、半径和 mask。若超过 85% 查询点在 base radius 内已有 `H` 个候选，则该 stage 的单纯半径扩张结构上偏弱。

## 进入正式实验的建议门槛

- graph change 至少 20%-30%；
- 平均每个查询点至少新增 1 个邻居；
- 相对 identity fixed test 的 mIoU 提升至少 0.8 个百分点，或边界/小类收益清晰且一致；
- 峰值显存增幅不超过 20%；
- 吞吐下降不超过 25%。

这些是进入下一阶段的工程判据，不是已观察到的实验结果。

## 对照公平性

官方 baseline、V13 与 V18 必须使用相同输入、训练预算、随机种子集合、checkpoint 选择、投票设置及 full-room restoration 协议。随机 validation 不应替代固定正式测试。

## 包内材料

- `evidence/`：Pro 原始评审、落地记录及 Standalone 设计说明。
- `source/`：V13/V18 核心实现、配置入口、审计与启动脚本。
- `tests/`：纯图逻辑测试。
- `UPSTREAM_LICENSE`：Apple 上游仓库许可证原文。

## 当前证据边界

已完成 7 项纯图算法测试、Python 编译检查与模型构造 smoke。尚未运行真实 S3DIS CUDA batch，因此显存、吞吐、精度和稳定性仍属于未验证项。
